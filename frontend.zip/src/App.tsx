import { FormEvent, useState } from 'react';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';

const FEE_WALLET = 'HevVj3XajvqbiZtxEwEZfEujr2UUm7qJfYLcE2unfd3H';

export default function App() {
  const { publicKey, connected } = useWallet();
  const { connection } = useConnection();
  const [tab, setTab] = useState<'create'|'trade'>('create');
  const [name, setName] = useState('');
  const [symbol, setSymbol] = useState('');
  const [description, setDescription] = useState('');
  const [mint, setMint] = useState('');
  const [notice, setNotice] = useState('Program on-chain belum di-deploy. Transaksi beli/jual belum aktif.');
  const [feeSol, setFeeSol] = useState('0.01');

  function submitCreate(e: FormEvent) {
    e.preventDefault();
    setNotice(`Draft token tersimpan di tampilan: ${name} (${symbol}). Belum membuat mint/token on-chain; program perlu selesai dan di-deploy terlebih dahulu.`);
  }

  async function checkBalance() {
    if (!publicKey) { setNotice('Hubungkan wallet terlebih dahulu.'); return; }
    try {
      const balance = await connection.getBalance(publicKey);
      setNotice(`Wallet terhubung. Saldo Devnet: ${(balance / 1e9).toFixed(4)} SOL. Ini bukan saldo Mainnet.`);
    } catch {
      setNotice('Tidak dapat membaca saldo Devnet. Periksa koneksi internet dan wallet.');
    }
  }

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-mark">L</span><span>LAUNCHPAD<span className="brand-dot">.</span><small>SOLANA COMMUNITY LAUNCHES</small></span></a>
      <div className="wallet"><WalletMultiButton /></div>
    </header>
    <main>
      <section className="hero">
        <div className="eyebrow"><span className="pulse"></span> COMMUNITY TOKEN LAUNCHES</div>
        <h1>Launch your token.<br/><span>Build your community.</span></h1>
        <p>Create a launch draft and explore the planned bonding-curve experience. On-chain launches are disabled until the program is complete and reviewed.</p>
        <div className="hero-stats"><div><strong>Solana</strong><small>NETWORK</small></div><div><strong>Bonding curve</strong><small>PLANNED MARKET</small></div><div><strong>Non-custodial</strong><small>WALLET SIGNING</small></div></div>
      </section>

      <nav className="tabs">
        <button className={tab==='create'?'active':''} onClick={()=>setTab('create')}>Create token</button>
        <button className={tab==='trade'?'active':''} onClick={()=>setTab('trade')}>Trade token</button>
      </nav>

      {tab === 'create' ? <section className="panel">
        <div className="panel-heading"><div><div className="eyebrow">TOKEN STUDIO</div><h2>Create a launch draft</h2></div><span className="status-chip">PREVIEW</span></div>
        <form onSubmit={submitCreate}>
          <label>Token name<input required maxLength={32} placeholder="e.g. Paw Panic" value={name} onChange={e=>setName(e.target.value)} /></label>
          <label>Ticker / symbol<input required maxLength={10} placeholder="e.g. PAW" value={symbol} onChange={e=>setSymbol(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,''))} /></label>
          <label>Description<textarea maxLength={500} rows={3} placeholder="What is your community about?" value={description} onChange={e=>setDescription(e.target.value)} /></label>
          <div className="grid2"><label>Initial buy (SOL)<input type="number" min="0" step="0.001" defaultValue="0" /></label><label>Service fee (SOL)<input type="number" min="0" step="0.001" value={feeSol} onChange={e=>setFeeSol(e.target.value)} /></label></div>
          <div className="fee-note"><span className="fee-icon">↗</span><div><strong>Service fee recipient</strong><small>{FEE_WALLET}</small><p>No copy-address button. Before enabling payment, verify the recipient and display the exact fee clearly.</p></div></div>
          <button className="primary" type="submit">Save launch draft <span>→</span></button>
          <p className="fineprint">This currently saves a draft in the page only. It does not create a token, charge a fee, or start a bonding curve.</p>
        </form>
      </section> : <section className="panel">
        <div className="panel-heading"><div><div className="eyebrow">MARKET</div><h2>Trade a token</h2></div><span className="status-chip disabled">NOT LIVE</span></div>
        <label>Token mint address<input placeholder="Enter a token mint address" value={mint} onChange={e=>setMint(e.target.value)} /></label>
        <div className="trade-placeholder"><div className="chart-icon">⌁</div><strong>Bonding curve is not live yet</strong><p>Buy and sell transactions will be enabled only after the Solana program is implemented, tested, audited, and deployed.</p></div>
        <div className="grid2"><button className="secondary" disabled>Buy token</button><button className="secondary" disabled>Sell token</button></div>
      </section>}

      <section className="notice"><span className="notice-dot"></span><div><strong>Development status</strong><p>{notice}</p><button className="text-button" onClick={checkBalance}>Check connected Devnet wallet balance</button></div></section>

      <section className="steps">
        <div className="eyebrow">ROADMAP</div><h2>From draft to live market</h2>
        <div className="step"><span>01</span><div><strong>Frontend and wallet UX</strong><p>UI, responsive layout, and wallet adapter integration.</p></div><em className="done">Starter included</em></div>
        <div className="step"><span>02</span><div><strong>Token factory + bonding curve</strong><p>Mint creation, curve math, SOL/token vaults, slippage limits and buy/sell instructions.</p></div><em>On-chain work</em></div>
        <div className="step"><span>03</span><div><strong>Tests and security review</strong><p>Local validator tests, devnet testing, invariant checks, and independent audit.</p></div><em>Required</em></div>
        <div className="step"><span>04</span><div><strong>Mainnet launch</strong><p>Deploy reviewed program, verify program ID, configure fee policy and publish monitoring.</p></div><em>Blocked</em></div>
      </section>
    </main>
    <footer><span>LAUNCHPAD<span className="brand-dot">.</span></span><span>Independent project · Not affiliated with Pump.fun</span></footer>
  </div>;
}
