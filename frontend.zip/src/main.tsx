import React, { useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { ConnectionProvider, WalletProvider } from '@solana/wallet-adapter-react';
import { WalletModalProvider, WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { PhantomWalletAdapter, SolflareWalletAdapter, BackpackWalletAdapter } from '@solana/wallet-adapter-wallets';
import App from './App';
import './styles.css';
import '@solana/wallet-adapter-react-ui/styles.css';

function Root() {
  // Development safety: this starter intentionally uses Devnet until the on-chain
  // program is complete, tested, audited and configured for Mainnet.
  const endpoint = 'https://api.devnet.solana.com';
  const wallets = useMemo(() => [
    new PhantomWalletAdapter(),
    new SolflareWalletAdapter(),
    new BackpackWalletAdapter(),
  ], []);
  return <ConnectionProvider endpoint={endpoint}>
    <WalletProvider wallets={wallets} autoConnect>
      <WalletModalProvider><App /></WalletModalProvider>
    </WalletProvider>
  </ConnectionProvider>;
}
createRoot(document.getElementById('root')!).render(<React.StrictMode><Root /></React.StrictMode>);
